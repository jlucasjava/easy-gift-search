/* Arquivo removido: não é mais necessário pois não há persistência local. */
