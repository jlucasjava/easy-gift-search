// Controller de recomendação inteligente (mock OpenAI)
exports.getRecommendation = (req, res) => {
  const { idade, genero, interesses } = req.body;
  // Exemplo de resposta mockada
  res.json({
    sugestao: `Sugestão inteligente para ${genero}, idade ${idade}: Livro de aventuras!`,
    produtosRelacionados: [
      { id: 101, nome: 'Livro Aventura', preco: 39.9, imagem: 'https://via.placeholder.com/150?text=Livro', url: 'https://www.amazon.com.br/' }
    ]
  });
};
